package com.myApp.chatapp.dao;

import static com.myApp.chatapp.dao.ConfigReader.getValue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public interface commonDAO {
	
	public static Connection createConnection() throws ClassNotFoundException, SQLException {
		// Load Driver
		Class.forName(getValue("DRIVER"));
		//Build Connection
		final String CON_STRING=getValue("CON_STRING");
		final String username=getValue("username");
		final String password=getValue("password");
		Connection con = DriverManager.getConnection(CON_STRING,username,password);
		if(con != null) {
			System.out.println("Connection Created");
			// con.close();
		}
		return con;
	}

	

}
