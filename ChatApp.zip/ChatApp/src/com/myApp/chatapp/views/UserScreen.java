package com.myApp.chatapp.views;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;


import com.myApp.chatapp.dao.UserDAO;
import com.myApp.chatapp.dto.UserDTO;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UserScreen extends JFrame{
	private JTextField textField;
	private JPasswordField passwordField;

	public static void main(String[] args) {
		UserScreen window = new UserScreen();
		}

	public UserScreen() {
		getContentPane().setBackground(new Color(255, 240, 245));
		setBounds(100, 100, 800, 451);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login Page");
		lblNewLabel.setForeground(new Color(204, 51, 0));
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 35));
		lblNewLabel.setBounds(304, 24, 158, 56);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter your UserID:");
		lblNewLabel_1.setForeground(new Color(204, 51, 51));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 23));
		lblNewLabel_1.setBounds(127, 118, 200, 56);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Enter your Password:");
		lblNewLabel_1_1.setForeground(new Color(204, 51, 51));
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 23));
		lblNewLabel_1_1.setBounds(127, 194, 200, 56);
		getContentPane().add(lblNewLabel_1_1);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 23));
		textField.setBackground(new Color(255, 204, 255));
		textField.setBounds(403, 118, 293, 56);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Times New Roman", Font.PLAIN, 23));
		passwordField.setBackground(new Color(255, 204, 255));
		passwordField.setBounds(403, 194, 293, 56);
		getContentPane().add(passwordField);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					doLogin();
				} catch (NumberFormatException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setForeground(new Color(255, 204, 255));
		btnNewButton.setBackground(new Color(153, 0, 153));
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 33));
		btnNewButton.setBounds(227, 295, 111, 56);
		getContentPane().add(btnNewButton);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doRegister();
			}
		});
		btnRegister.setForeground(new Color(255, 204, 255));
		btnRegister.setBackground(new Color(153, 0, 153));
		btnRegister.setFont(new Font("Calibri", Font.BOLD, 33));
		btnRegister.setBounds(403, 295, 151, 56);
		getContentPane().add(btnRegister);
		setVisible(true);
	}
	UserDAO userdao = new UserDAO();
	private void doRegister() {
		String userid = textField.getText();
		char []password = passwordField.getPassword();
		UserDTO userDTO = new UserDTO(userid,password);
		try {
			int record=userdao.register(userDTO);
			if(record>0) {
				JOptionPane.showMessageDialog(this, "Registered Sucessfully!!!!!!");
			}else {
				JOptionPane.showMessageDialog(this, "Registration Unsucessfull!!!!!!");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	private void doLogin() throws NumberFormatException, UnknownHostException, IOException {
		String userid = textField.getText();
		char []password = passwordField.getPassword();
		UserDTO userDTO = new UserDTO(userid,password);
		try {
			boolean res=userdao.isLogin(userDTO);
			if(res) {
				setVisible(false);
				dispose();
				JOptionPane.showMessageDialog(this, "Login Success...");
				chatScreen chatWindow = new chatScreen(userid);
				chatWindow.setVisible(true);
			}else {
				JOptionPane.showMessageDialog(this, "Login Failed!!!!!!");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
