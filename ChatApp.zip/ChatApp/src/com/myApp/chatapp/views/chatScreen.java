package com.myApp.chatapp.views;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.myApp.chatapp.networking.Client;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class chatScreen extends JFrame{
	private JTextField textField;
	private String useridString;
	//public static void main(String[] args) {
		//chatScreen window = new chatScreen();
		//window.setVisible(true);
		//}
	private void sendMessage() throws IOException {
		String messageString = textField.getText();
		client.sendMessage(this.useridString + ": "+messageString);
		
	}
	private Client client;
	private JTextArea textArea = new JTextArea();
	public chatScreen(String useridString) throws NumberFormatException, UnknownHostException, IOException {
		getContentPane().setBackground(new Color(255, 240, 245));
		getContentPane().setLayout(null);
		this.useridString=useridString;
		textArea = new JTextArea();
		client = new Client(textArea);
		textArea.setBackground(new Color(255, 255, 204));
		textArea.setBounds(10, 10, 766, 297);
		getContentPane().add(textArea);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 23));
		textField.setBackground(new Color(255, 204, 255));
		textField.setBounds(10, 328, 545, 64);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Send Message");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					sendMessage();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(570, 328, 206, 64);
		btnNewButton.setForeground(new Color(255, 204, 255));
		btnNewButton.setBackground(new Color(153, 0, 153));
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 28));
		getContentPane().add(btnNewButton);
		setBounds(100, 100, 800, 451);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
//	public static void main(String[] args) throws UnknownHostException, IOException {
//	chatScreen window = new chatScreen();
//	window.setVisible(true);
//}
}
