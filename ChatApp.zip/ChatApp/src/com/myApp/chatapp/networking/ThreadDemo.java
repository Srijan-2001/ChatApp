package com.myApp.chatapp.networking;
/*
 * Thread=worker
 * worker needs a job
 * for job we use runnable
 * once job is created via runnable then we write logic inside run
 */
public class ThreadDemo extends Thread// implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//job to perform
		for(int i=1;i<=5;i++) {
			System.out.println("I is: "+i+" Thread is: "+Thread.currentThread());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		ThreadDemo job = new ThreadDemo();
		job.start();
		//Assign job to the thread
		//Thread worker = new Thread(job);
		//worker.start();// Internally it will call run()
		for(int i=0;i<=5;i++) {
			System.out.println("Main: "+i+" Thread is: "+Thread.currentThread());
		}
	}

}
