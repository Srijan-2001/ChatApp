/**
 * 
 */
package com.myApp.chatapp.networking;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.myApp.chatapp.dao.ConfigReader;

/**
 * @author DELL
 *
 */
public class Server {
	ServerSocket serverSocket;
	ArrayList<ServerWorker> workers = new ArrayList<ServerWorker>();
	public Server() throws IOException {
		// TODO Auto-generated constructor stub
		int PORT = Integer.parseInt(ConfigReader.getValue("PORTNO"));
		serverSocket = new ServerSocket(PORT);
		while(true) {
			System.out.println("Waiting for client");
			handleClient();
		}
	}
	
public void handleClient() throws IOException {
		// TODO Auto-generated method stub
	Socket socket = serverSocket.accept();// Handshaking with client
	System.out.println("Client Connected with Server.....");
	// Thread Per Client
	ServerWorker serverWorker=new ServerWorker(socket,this);
	workers.add(serverWorker);
	serverWorker.start();
		
	}

//ForSingle client
//	public Server() throws IOException {
//		// TODO Auto-generated constructor stub
//		int PORT = Integer.parseInt(ConfigReader.getValue("PORTNO"));
//		serverSocket = new ServerSocket(PORT);
//		System.out.println("Server Started.....Waiting for Client....");
//		Socket socket = serverSocket.accept();// Handshaking with client
//		System.out.println("Client Connected with Server.....");
//		InputStream in = socket.getInputStream();//reads byte from network
//		byte[] arr=in.readAllBytes();
//		String str = new String(arr);
//		System.out.println("Client: "+str);
//		in.close();
//		socket.close();
//	}

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Server server = new Server();

	}

}
