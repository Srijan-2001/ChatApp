/**
 * 
 */
package com.myApp.chatapp.networking;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.swing.JTextArea;

import com.myApp.chatapp.dao.ConfigReader;

/**
 * @author DELL
 *
 */
public class Client {
	Socket socket;
	OutputStream out;
	InputStream in;
	ClientWorker worker;
	JTextArea textArea;

	public Client(JTextArea textArea) throws NumberFormatException, UnknownHostException, IOException {
		int PORT = Integer.parseInt(ConfigReader.getValue("PORTNO"));
		// We need server machine Ip and Port
		socket = new Socket(ConfigReader.getValue("SERVER_IP"), PORT);
		System.out.println("Client Arrived....");
		out = socket.getOutputStream();//send
		in = socket.getInputStream();//recieive
		this.textArea = textArea;
		readMessage();
		// TODO Auto-generated constructor stub
		// we need server machine Ip and Port
//		socket = new Socket(ConfigReader.getValue("SERVER_IP"),(int)Integer.parseInt(ConfigReader.getValue("PORTNO")));
//		System.out.println("Client Arrived....");
//		System.out.println("Enter your message: ");
//		Scanner scanner = new Scanner(System.in);
//		String message = scanner.nextLine();
//		OutputStream out = socket.getOutputStream();// write bytes on network
//		out.write(message.getBytes());//convert to byte
//		out.close();
//		socket.close();
	}

	/**
	 * @param args
	 * @throws IOException 
	 * @throws UnknownHostException 
	 * @throws NumberFormatException 
	 */
	public void readMessage() {
		// client worker will read message from the network
		worker = new ClientWorker(in,textArea);
		worker.start();
		
	}
	public void sendMessage(String message) throws IOException {
		// write message on network
		out.write((message+"\n").getBytes());
	}
	
//	public static void main(String[] args) throws NumberFormatException, UnknownHostException, IOException {
//		// TODO Auto-generated method stub
//		Client client = new Client();
//	}

}
