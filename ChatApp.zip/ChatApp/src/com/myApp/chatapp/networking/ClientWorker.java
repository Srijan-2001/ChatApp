/**
 * 
 */
package com.myApp.chatapp.networking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JTextArea;
import javax.swing.text.AbstractDocument.BranchElement;

/**
 * @author DELL
 *
 */
public class ClientWorker extends Thread{
	private InputStream in;
	private JTextArea textArea;

	/**
	 * 
	 */
	public ClientWorker(InputStream in,JTextArea textArea) {
		// TODO Auto-generated constructor stub
		this.in=in;
		this.textArea=textArea;
	}

	/**
	 * @param args
	 */
	public void run() {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
		String line;
		try {
			while(true) {
				line = bufferedReader.readLine();
				textArea.setText(textArea.getText()+line+"\n");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			if(bufferedReader!=null) {
				try {
					bufferedReader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
