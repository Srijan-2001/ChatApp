/**
 * 
 */
package com.myApp.chatapp.networking;

import java.io.*;
import java.net.Socket;

/**
 * @author DELL
 *
 */
public class ServerWorker extends Thread{
	private Socket clientSocket;
	private InputStream in;
	private OutputStream out;
	private Server server;

	/**
	 * @throws IOException 
	 * 
	 */
	public ServerWorker(Socket clientSocket, Server server) throws IOException {
		this.clientSocket = clientSocket;
		this.server = server;
		in = clientSocket.getInputStream(); // read data from client
		out = clientSocket.getOutputStream(); //write data back to client
	}
	@Override
	public void run() {
		// job of worker/ logic
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
		String line;
		try {
			while(true) {
				line = bufferedReader.readLine();
				System.out.println("Line : "+ line);
				//Now broadcast message to all clients....
				for(ServerWorker serverWorker : server.workers) {
					serverWorker.out.write((line+"\n").getBytes());
					
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				if(bufferedReader!=null) {
					bufferedReader.close();
				}
				if(in!=null) {
					in.close();
				}
				if(out!=null) {
					out.close();
				}
				if(clientSocket!=null) {
					clientSocket.close();
				}
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
			
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
}
